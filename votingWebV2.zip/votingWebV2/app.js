let web3;
let contract;
let adminAddress;

const connectMetamask = async () => {
  if (typeof window.ethereum !== 'undefined') {
    try {
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      web3 = new Web3(window.ethereum);
      contract = new web3.eth.Contract(contractABI, contractAddress);
      console.log('Connected to MetaMask');
      await updateAdminAddress();
      await displayCandidates();
    } catch (error) {
      console.error('Error connecting to MetaMask:', error);
    }
  } else {
    console.error('MetaMask not detected');
    alert('Please install MetaMask to use this application.');
  }
};

const updateAdminAddress = async () => {
  adminAddress = await contract.methods.getVotingAdmin().call();
}

const startElection = async () => {
  try {
    
    const accounts = await web3.eth.getAccounts();

    if (accounts[0].toLowerCase() === adminAddress.toLowerCase()) {
      await contract.methods.startElection().send({ from: accounts[0] });
      console.log('Election started');
      await displayCandidates();
    } else {
      console.error('Only the admin can start the election');
      alert('Only the admin can start the election');
    }
  } catch (error) {
    console.error('Error starting election:', error);
  }
};

const endElection = async () => {
  try {
    const accounts = await web3.eth.getAccounts();

    // const adminAddress = await contract.methods.getVotingAdmin().call();

    if (accounts[0].toLowerCase() === adminAddress.toLowerCase()) {
      await contract.methods.endElection().send({ from: accounts[0] });
      console.log('Election ended');
      await displayCandidates();
    } else {
      console.error('Only the admin can end the election');
      alert('Only the admin can end the election');
    }
  } catch (error) {
    console.error('Error ending election:', error);
  }
};

const displayCandidates = async () => {
  console.log('Displaying candidates...');
  try {
    const candidateSelect = document.getElementById('candidateSelect');
    candidateSelect.innerHTML = '';

    const accounts = await web3.eth.getAccounts();

    if (accounts[0].toLowerCase() != adminAddress.toLowerCase()) {
      const startButton = document.getElementById('startElectionBtn');
      startButton.disabled = true;
      startButton.style.visibility = 'hidden';
      // document.getElementById('endElectionBtn').style.display = none;
    } else {
      console.log('Not Admin');
    }

    const candidateCount = await contract.methods.getCandidateCount().call();
    
    let i = 0;
    while (i<candidateCount) {
      try {
        const candidate = await contract.methods.getCandidateByIndex(i).call();
        const option = document.createElement('option');
        option.value = i;
        option.textContent = `${candidate.name} - Votes: ${candidate.voteCount}`;
        candidateSelect.appendChild(option);
        i++;
      } catch (error) {
        break;
      }
    }
  } catch (error) {
    console.error('Error displaying candidates:', error);
  }
};

const vote = async () => {
  try {
    const candidateSelect = document.getElementById('candidateSelect');
    const candidateIndex = candidateSelect.value;
    const accounts = await web3.eth.getAccounts();
    const voterAddress = accounts[0];
    const isValidVoter = await contract.methods.isValidVoter(voterAddress).call();

    if (!isValidVoter) {
      alert('You have already voted!');
      return;
    }

    await contract.methods.vote(candidateIndex).send({ from: voterAddress });
    console.log('Vote submitted');
    alert('Vote submitted successfully!');
    await displayCandidates();
  } catch (error) {
    console.error('Error submitting vote:', error);
  }
};

const displayResults = async () => {
  try {
    // const resultsDiv = document.getElementById('results');
    // if (resultsDiv) {
    //   resultsDiv.innerHTML = '';

      const winningCandidate = await contract.methods.winningCandidate().call();

      alert(winningCandidate+' won');

      // const resultItem = document.createElement('div');
      // resultItem.className = 'bg-white shadow-md rounded-md p-4';
      // resultItem.innerHTML = `
      //   <h3 class="text-xl font-semibold mb-2">Winner</h3>
      //   <p class="text-lg">${winningCandidate.name}</p>
      //   <p class="text-gray-600">Votes: ${winningCandidate.voteCount}</p>
      // `;
      // resultsDiv.appendChild(resultItem);
    } catch (error) {
    console.error('Error displaying results:', error);
  }
};

//event listeners
document.getElementById('connectMetamask').addEventListener('click', connectMetamask);
document.getElementById('startElectionBtn').addEventListener('click', startElection);
document.getElementById('endElectionBtn').addEventListener('click', endElection);
document.getElementById('voteButton').addEventListener('click', vote);
document.getElementById('resultsButton').addEventListener('click', displayResults);

// Initial setup
// connectMetamask(displayCandidates);
connectMetamask();
// displayCandidates();
// displayResults();